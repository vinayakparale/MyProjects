package com.capg.practice.accountmanagement.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="my_account")
@Entity
public class Account {
	
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	@Column(name = "acctId")
	private Integer id;
	
	@Column(name = "accountNumber")
	private Integer  acctNumber;
	
	@Column(name = "amount")
	private String  amount;
	
	@Column(name = "accountName")
	private String name;
	
	@Column(name = "emailid")
	private String emailid;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "phonenumber")
	private Integer phonenumber;

	public Account() {
	}

	public Account(Integer id, Integer acctNumber, String amount, String name, String emailid, String address, Integer phonenumber) {
		this.id = id;
		this.acctNumber = acctNumber;
		this.amount = amount;
		this.name = name;
		this.emailid = emailid;
		this.address = address;
		this.phonenumber = phonenumber;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAcctNumber() {
		return acctNumber;
	}

	public void setAcctNumber(Integer acctNumber) {
		this.acctNumber = acctNumber;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(Integer phonenumber) {
		this.phonenumber = phonenumber;
	}

	@Override
	public String toString() {
		return "Account [id=" + id + ", acctNumber=" + acctNumber + ", amount=" + amount + ", name=" + name
				+ ", emailid=" + emailid + ", address=" + address + ", phonenumber=" + phonenumber + "]";
	}


	
	
}
