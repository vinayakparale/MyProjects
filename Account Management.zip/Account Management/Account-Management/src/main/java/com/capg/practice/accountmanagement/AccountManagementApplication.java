package com.capg.practice.accountmanagement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import com.capg.practice.accountmanagement.dao.AccountManagementRepository;
import com.capg.practice.accountmanagement.domain.Account;

import springfox.documentation.swagger2.annotations.EnableSwagger2;


@SpringBootApplication
@EnableSwagger2
@Configuration
public class AccountManagementApplication implements CommandLineRunner{

	private static final Logger logger = LoggerFactory.getLogger(AccountManagementApplication.class);
	@Autowired
	AccountManagementRepository repository;
	
	public static void main(String[] args) {
		SpringApplication.run(AccountManagementApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
	logger.info("=============Executing SQL Script====================");
	repository.save(new Account(null, 1001, "500", "Vinayak Parale", "abc@gmail.com", "Pune", 123456892));
	repository.save(new Account(null, 1002, "300", "Diego Maradona", "abc@gmail.com", "Mumbai", 123457893));
	repository.save(new Account(null, 1003, "405", "Brian Lara", "abc@gmail.com", "Delhi", 123458752));
	repository.save(new Account(null, 1004, "60", "David Beckham", "abc@gmail.com", "kolkata", 123459470));
		
	}

}
