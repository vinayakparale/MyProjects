package com.capg.practice.accountmanagement.service;

import java.util.List;

import com.capg.practice.accountmanagement.domain.Account;


public interface AccountService {

	void createAccount(Account account);

	void updateAccount(Account account);

	void deleteAccount(int accountId);

	Account findAcountById(int accountId);

	List<Account> findAllAccounts();
	
	Account withdrawlAmount(int acctId, String amount);
	
	Account depositAmount(int acctId, String amount);
}
