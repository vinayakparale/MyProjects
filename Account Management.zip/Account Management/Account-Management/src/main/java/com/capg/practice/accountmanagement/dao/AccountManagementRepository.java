package com.capg.practice.accountmanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.capg.practice.accountmanagement.domain.Account;

@Repository
public interface AccountManagementRepository extends JpaRepository<Account, Integer>{
	

}