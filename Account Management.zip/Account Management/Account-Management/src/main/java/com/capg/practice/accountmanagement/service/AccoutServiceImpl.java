package com.capg.practice.accountmanagement.service;

import java.util.List;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import com.capg.practice.accountmanagement.dao.AccountManagementRepository;
import com.capg.practice.accountmanagement.domain.Account;

@Service
public class AccoutServiceImpl implements AccountService{
	private static final Logger logger = LoggerFactory.getLogger(AccoutServiceImpl.class);

	@Autowired
	private AccountManagementRepository repository;

	@Override
	public void createAccount(Account account) {
	logger.info("createAccount :: Account Created");
		repository.save(account);
		
	}

	@Override
	public void updateAccount(Account account) {
	logger.info("updateAccount :: Account Updated");
		repository.save(account);
	}
	
	@Override
	public Account withdrawlAmount(int accountId, String value) {
			
		JSONObject jsonObj = new JSONObject(value); 
		String amt = jsonObj.getString("amount");
		Account acct = repository.findById(accountId).get();
		 
		int currentAmount = Integer.parseInt(acct.getAmount());
		 int withdrawlAmount = Integer.parseInt(amt);
		 int latestValue = currentAmount - withdrawlAmount;
					
		 if ((currentAmount > 0) && (currentAmount > withdrawlAmount)) {
			 acct.setAmount(String.valueOf(latestValue)); 
			 repository.save(acct);
		 }else {
			 logger.debug("withdrawlAmount :: Insufficient funds available");
			 throw new ResponseStatusException(HttpStatus.NOT_ACCEPTABLE, "Insufficient funds available", null); 
		 }
		 
		return acct;
		
	}

	@Override
	public Account depositAmount(int accountId, String value) {
				
		JSONObject jsonObj = new JSONObject(value);
		String amt = jsonObj.getString("amount");
		Account acct = repository.findById(accountId).get();
		
		 int currentAmount = Integer.parseInt(acct.getAmount());
		 int withdrawlAmount = Integer.parseInt(amt);
		 int latestValue = currentAmount + withdrawlAmount;
		
		 acct.setAmount(String.valueOf(latestValue)); 
		 repository.save(acct);
		return acct;
		
	}

	@Override
	public void deleteAccount(int accountId) {
		 if(repository.existsById(accountId)) {
			 logger.info("deleteAccount :: Account Deleted");
		    	repository.deleteById(accountId);
		 }else {
			 logger.info("deleteAccount :: Account Not Found");
			 throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Account details Not Found", null);
		 }
		
	}

	@Override
	public Account findAcountById(int accountId) {
		Account acct=null;
		try {
			 acct =	repository.findById(accountId).get();
			
		}catch (Exception exc) {
			logger.debug("findAcountById :: Account details Not Found");
			 throw new ResourceNotFoundException("Account details Not Found");
	    }
		return acct;
	}

	@Override
	public List<Account> findAllAccounts() {
		logger.info("findAllAccounts :: Show all Accounts");
		return repository.findAll();
		
	}
	
}