package com.capg.practice.accountmanagement.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capg.practice.accountmanagement.domain.Account;
import com.capg.practice.accountmanagement.service.AccountService;
import org.json.*;

@RestController
@RequestMapping("/accounts")
public class AccountRestController {
	


	@Autowired
	AccountService accountService;
	

@ResponseStatus(value = HttpStatus.CREATED)
@PostMapping
public void createAccount(@RequestBody  Account account) {
	accountService.createAccount(account);
}	

@ResponseStatus(value = HttpStatus.OK)
@PutMapping
public void updateAccount(@RequestBody Account account) {
	accountService.updateAccount(account);
}	


@ResponseStatus(value = HttpStatus.OK)
@DeleteMapping(path = "/{acctId}")
public void deleteAccount(@PathVariable("acctId")int acctId) {
	accountService.deleteAccount(acctId);
}	


@GetMapping("/{acctId}")
public Account findAccount(@PathVariable("acctId")int acctId) {
	return accountService.findAcountById(acctId);
}	

@GetMapping
public List<Account> findAllAccounts() {
	return accountService.findAllAccounts();
}	



@PutMapping("/withdrawl/{acctId}")
public Account makeWithDrrawl(@PathVariable("acctId")int acctId, @RequestBody String amount){
	return accountService.withdrawlAmount(acctId, amount); 
}
  
@PutMapping("/deposit/{acctId}")
public Account makeDeposit(@PathVariable("acctId")int acctId, @RequestBody String amount) {
  return accountService.depositAmount(acctId, amount); 
}
 
}
